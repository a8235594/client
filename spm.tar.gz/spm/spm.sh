!/bin/bash


./1 -license yes -gpuServer

